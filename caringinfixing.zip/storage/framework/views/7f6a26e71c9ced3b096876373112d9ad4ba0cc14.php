<div class="table-responsive py-4">
    <table class="table table-flush" width="100%" id="userNasabah">
        <thead class="thead-light">
            <tr>
                <th class="text-center" style="max-width:35%">Username</th>
                <th class="text-center" style="min-width:100px;max-width:35%">Nama</th>
                <th class="text-center" style="max-width:15%">Action</th>
                <th class="text-center" style="max-width:15%">Details</th>
            </tr>
        </thead>
    </table>
</div><?php /**PATH C:\xampp\htdocs\caringinfixing\resources\views/user/nasabah.blade.php ENDPATH**/ ?>