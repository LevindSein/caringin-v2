<div class="table-responsive py-4">
    <table class="table table-flush" width="100%" id="tabelAlatAir">
        <thead class="thead-light">
            <tr>
                <th class="text-center" style="max-width:20%">Kode</th>
                <th class="text-center" style="min-width:80px;max-width:25%">Nomor</th>
                <th class="text-center" style="max-width:25%">Stand</th>
                <th class="text-center" style="max-width:15%">Status</th>
                <th class="text-center" style="max-width:15%">Action</th>
            </tr>
        </thead>
    </table>
</div><?php /**PATH C:\xampp\htdocs\caringinfixing\resources\views/utilities/alat-meter/air-bersih.blade.php ENDPATH**/ ?>