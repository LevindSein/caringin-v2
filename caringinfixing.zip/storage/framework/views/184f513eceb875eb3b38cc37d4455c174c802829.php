<?php 
use App\Models\IndoDate;

function indoDate($tanggal){
    return IndoDate::bulan($tanggal,' ');
}
?>



<?php $__env->startSection('title'); ?>
<title>Laporan Pemakaian | BP3C</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul'); ?>
<h6 class="h2 text-white d-inline-block mb-0">Laporan Pemakaian</h6>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('button'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<span id="form_result"></span>
<div class="row">
    <div class="col-xl-12">
        <div class="card shadow mb-4">
            <div class="card-body">
                <div class="table-responsive py-4">
                    <table class="table table-flush" width="100%" id="pemakaian">
                        <thead class="thead-light">
                            <tr>
                                <th class="text-center" style="max-width:70%">Bulan</th>
                                <th class="text-center" style="max-width:30%">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $dataset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center-td" <?php $bulan = indoDate($d->bln_pakai); ?>><?php echo e($bulan); ?></td>
                                <td class="text-center">
                                    <button title="Cetak Pemakaian" name="cetak" id="<?php echo e($d->bln_pakai); ?>" nama="<?php echo e($bulan); ?>" class="cetak btn btn-sm btn-primary">Cetak</button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
<div id="myModal" class="modal fade" role="dialog" tabIndex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title titles"></h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form id="form_pemakaian" target="_blank" method="POST" action="<?php echo e(url('rekap/pemakaian')); ?>">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="form-group">
                        <label class="form-control-label" for="fasilitas">Pilih Fasilitas</label>
                        <select class="form-control" id="fasilitas" name="fasilitas">
                            <option value="listrik">Listrik</option>
                            <option value="airbersih">Air Bersih</option>
                            <option value="keamananipk">Keamanan & IPK</option>
                            <option value="kebersihan">Kebersihan</option>
                            <option value="airkotor">Air Kotor</option>
                            <option value="lain">Lain - Lain</option>
                            <option value="total">Total Pemakaian</option>
                            <option value="diskon">Pengguna Diskon</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-sm btn-light" data-dismiss="modal">Batal</button>
                    <input type="hidden" id="hidden_value" name="hidden_value" />
                    <input type="submit" class="btn btn-sm btn-primary" value="Cetak" />
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('js/laporan/pemakaian.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\caringinfixing\resources\views/laporan/pemakaian/index.blade.php ENDPATH**/ ?>