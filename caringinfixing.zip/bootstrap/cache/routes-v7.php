<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lpzsu0Zxx8paIJAO',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::v7nqnHlVpOftN9nW',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/storelogin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Tm0EsBLw3hM5mfl5',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hrxjFa6zVoMkRHcj',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/pedagang' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pedagang.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'pedagang.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/tempatusaha/alat' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::59gerJMw4RSwiWhx',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/tempatusaha/rekap' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::szTpLnWmCbaudzm9',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/tempatusaha/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HIfhwu03slitMY1V',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/tempatusaha' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempatusaha.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'tempatusaha.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/tempatusaha/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempatusaha.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/rekap/pemakaian' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::smLGpAOS4LgmAvQX',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wt5WTuNFoABFtbHo',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/rekap/pendapatan/tahunan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fsYWkHvAY4DPfNWL',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/rekap/pendapatan/bulanan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ufTb1JIMWE6cIsDf',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/rekap/pendapatan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pendapatan.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'pendapatan.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/rekap/pendapatan/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pendapatan.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/utilities/tarif' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xVXNeWXeqlGMfdDm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/utilities/tarif/keamananipk' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZAiteGElDo8Yvj2t',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/utilities/tarif/kebersihan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::scHuz4ncdDNXPBAX',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/utilities/tarif/airkotor' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gmmI2aXmyixWTmEu',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/utilities/tarif/lain' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bxXROD2koPhPiAes',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/utilities/tarif/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LXwFQ2cntwPFo2E9',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/utilities/tarif/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GySUwRwFgUaaemKI',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/utilities/alatmeter' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uKhxdRB1o6wRS0vx',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/utilities/alatmeter/air' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::N8nydXHMvo3ZHXxU',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/utilities/alatmeter/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jeLzI8sc0klwelSB',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/utilities/alatmeter/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bqPzWlfjEAlnmZwN',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/utilities/harilibur' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kMjlsF56mLolBsHP',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/utilities/harilibur/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5eGqbtdvh0zgf8JT',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/utilities/harilibur/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7ehynQY0KqcLPrs1',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/utilities/blok' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RP3qmMwLUlywbYhw',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/utilities/blok/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kpXoZp5ZTqpnVvPO',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/utilities/blok/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bM2RMrDr23Ndk0YY',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/utilities/simulasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vzqhCxGVtjTI1gNa',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::H3YB2qbn3dQQtXWB',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/master/kasir/sisa' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BeAKpAV6hbPxffb7',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/master/kasir/harian/data/perkiraan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9Y6r8my13j3MLL6J',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/master/kasir' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FOYklVoaNVlEESj6',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/master/kasir/edit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DeOevNIdqakJSzsY',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qHbr6MWHghwlhn1P',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/otoritas' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fcr9qqcC2OB6WoEC',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/manajer' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RZ0F6MkiWeTRceKf',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/keuangan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::J4aw2ejDcKfxBUd2',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/kasir' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OIBfwLd3ljoX2qrl',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/nasabah' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LfRGmnNIe7BHQbYc',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'user.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/log' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::50IOlV0MMlUZnwXY',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/cari/blok' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JuTM3MDk7CZOTOHc',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/cari/nasabah' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::V38nJXMgVL3f0MwR',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/cari/alamat' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BOVLiHsQPqd955aj',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/cari/alamat/kosong' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9IRvWlVsc0rXRTSl',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/cari/alatlistrik' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::o0CrLjlnoShGkcgq',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/cari/alatair' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hL1uXBlErEimQFBH',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/work' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SK1YqKKdvsJZL81s',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/work/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8ebwlg4P9im8GTIw',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/optimize.p3cmaster' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::21aYF6dhr8RCKrAv',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/pedagang/(?|([^/]++)(*:28)|update(*:41)|destroy/([^/]++)(*:64)|create(*:77)|([^/]++)(?|(*:95)|/edit(*:107)|(*:115)))|/tempatusaha/(?|show/([^/]++)(*:154)|qr/([^/]++)(*:173)|rekap/([^/]++)(*:195)|fasilitas/([^/]++)(*:221)|destroy/([^/]++)(*:245)|([^/]++)(?|(*:264)|/edit(*:277)|(*:285)))|/rekap/pendapatan/([^/]++)(?|(*:324)|/edit(*:337)|(*:345))|/u(?|tilities/(?|tarif/(?|edit/([^/]++)/([^/]++)(*:402)|destroy/([^/]++)/([^/]++)(*:435))|alatmeter/(?|edit/([^/]++)/([^/]++)(*:479)|destroy/([^/]++)/([^/]++)(*:512)|qr/([^/]++)/([^/]++)(*:540))|harilibur/(?|edit/([^/]++)(*:575)|destroy/([^/]++)(*:599))|blok/(?|edit/([^/]++)(*:629)|destroy/([^/]++)(*:653)))|ser/(?|de(?|tails/([^/]++)(*:689)|stroy/([^/]++)(*:711))|reset/([^/]++)(*:734)|([^/]++)(?|/(?|otoritas(*:765)|edit(*:777))|(*:786))))|/master/kasir/(?|harian/data/perkiraan/destroy/([^/]++)(*:852)|restore/([^/]++)(*:876)|struk/([^/]++)/([^/]++)(*:907))|/cari/(?|tagihan/([^/]++)(?|(*:944)|/([^/]++)(*:961))|l(?|istrik/([^/]++)(*:989)|ain/([^/]++)(*:1009))|air(?|bersih/([^/]++)(*:1040)|kotor/([^/]++)(*:1063))|ke(?|amananipk/([^/]++)(*:1096)|bersihan/([^/]++)(*:1122))))/?$}sDu',
    ),
    3 => 
    array (
      28 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Rj6YKRnA9hxn6ce4',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      41 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uv3DeBmQodSR38De',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      64 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rvFVK0i26iNWDEeN',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      77 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pedagang.create',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      95 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pedagang.show',
          ),
          1 => 
          array (
            0 => 'pedagang',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      107 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pedagang.edit',
          ),
          1 => 
          array (
            0 => 'pedagang',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      115 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pedagang.update',
          ),
          1 => 
          array (
            0 => 'pedagang',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'pedagang.destroy',
          ),
          1 => 
          array (
            0 => 'pedagang',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      154 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SQn9vzPlt9vaODSa',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      173 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2GAdFgAydVGwWk1F',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      195 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::g6Y4urqZsIhgGfca',
          ),
          1 => 
          array (
            0 => 'blok',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      221 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VA4iG74wN18ohvP2',
          ),
          1 => 
          array (
            0 => 'fas',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      245 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FzeVscXwIEO2sTsZ',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      264 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempatusaha.show',
          ),
          1 => 
          array (
            0 => 'tempatusaha',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      277 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempatusaha.edit',
          ),
          1 => 
          array (
            0 => 'tempatusaha',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      285 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempatusaha.update',
          ),
          1 => 
          array (
            0 => 'tempatusaha',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'tempatusaha.destroy',
          ),
          1 => 
          array (
            0 => 'tempatusaha',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      324 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pendapatan.show',
          ),
          1 => 
          array (
            0 => 'pendapatan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      337 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pendapatan.edit',
          ),
          1 => 
          array (
            0 => 'pendapatan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      345 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pendapatan.update',
          ),
          1 => 
          array (
            0 => 'pendapatan',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'pendapatan.destroy',
          ),
          1 => 
          array (
            0 => 'pendapatan',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      402 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1N8GWonL3fzBUwVq',
          ),
          1 => 
          array (
            0 => 'fasilitas',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      435 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mK5rk1p1e67c3HH2',
          ),
          1 => 
          array (
            0 => 'fasilitas',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      479 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::b4NH9tqOT0OOwMCX',
          ),
          1 => 
          array (
            0 => 'fasilitas',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      512 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RubKkwoKJep05Z2X',
          ),
          1 => 
          array (
            0 => 'fasilitas',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      540 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GngAOwx50UO1giso',
          ),
          1 => 
          array (
            0 => 'fasilitas',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      575 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SVnHx1RQtethFJtb',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      599 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6fL0Q4sqEFPADlrh',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      629 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tG3owEW3K7lpd9HI',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      653 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qgBzs6HObqc7aQhS',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      689 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8iQpyhc0nJVR7wvn',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      711 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::n5Ff7zfIRjoNYnQp',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      734 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lrPL1SyQUEJ835JN',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      765 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::axaT3C7ySyHwXZe2',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      777 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.edit',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      786 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.show',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'user.update',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'user.destroy',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      852 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5M2K5MY1P47PPrZE',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      876 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bynOActrEMOBtMuB',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      907 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VHAfBvxDRLlF75Us',
          ),
          1 => 
          array (
            0 => 'struk',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      944 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xYXz86jkjsMi1WJy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      961 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::F8GfvCATQrQTPrj0',
          ),
          1 => 
          array (
            0 => 'fasilitas',
            1 => 'kontrol',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      989 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YDhUjHosonkF9x5Q',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1009 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9rvfgtEuO3qZYXWU',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1040 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::u8IknJmuVJjpqCav',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1063 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::j92FSLBorCRUOj7H',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1096 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uw2LFe5zziQPmNrH',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1122 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ryOFabexOX0jD8V8',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::lpzsu0Zxx8paIJAO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:api',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":289:{@570TpyFB87CmpvlMddm/giRqBaDb7nhlQngo59a8utw=.a:5:{s:3:"use";a:0:{}s:8:"function";s:77:"function (\\Illuminate\\Http\\Request $request) {
    return $request->user();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000001b72805d000000005a317f3f";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::lpzsu0Zxx8paIJAO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::v7nqnHlVpOftN9nW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":267:{@X3Ym/aeErl3McC0pGoI7sLSrjkoA71Ja5MKF2t/0RSc=.a:5:{s:3:"use";a:0:{}s:8:"function";s:55:"function () {
    return \\redirect()->route(\'login\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000001b728063000000005a317f3f";}}',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::v7nqnHlVpOftN9nW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":1266:{@xuPhdZ1XmElTMvW7CCK+4ZUFbi2S10zbXLt+esUfmR8=.a:5:{s:3:"use";a:0:{}s:8:"function";s:1052:"function(){
    $time = "unknown";
    $now = \\Carbon\\Carbon::now();
    $start = \\Carbon\\Carbon::createFromTimeString(\'04:00\');
    $end = \\Carbon\\Carbon::createFromTimeString(\'10:00\');
    if ($now->between($start, $end)){
        $time = "pagi";
    }
    $start = \\Carbon\\Carbon::createFromTimeString(\'10:00\');
    $end = \\Carbon\\Carbon::createFromTimeString(\'15:00\');
    if ($now->between($start, $end)){
        $time = "siang";
    }
    $start = \\Carbon\\Carbon::createFromTimeString(\'15:00\');
    $end = \\Carbon\\Carbon::createFromTimeString(\'19:00\');
    if ($now->between($start, $end)){
        $time = "sore";
    }
    $start = \\Carbon\\Carbon::createFromTimeString(\'19:00\');
    $end = \\Carbon\\Carbon::createFromTimeString(\'23:59\');
    if ($now->between($start, $end)){
        $time = "malam";
    }
    $start = \\Carbon\\Carbon::createFromTimeString(\'00:00\');
    $end = \\Carbon\\Carbon::createFromTimeString(\'04:00\');
    if ($now->between($start, $end)){
        $time = "malam";
    }

    return \\view(\'home.login\',[\'time\'=>$time]);
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000001b728061000000005a317f3f";}}',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Tm0EsBLw3hM5mfl5' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'storelogin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:home',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":1091:{@3mLruokfpfoSKLm2zUruOAypoJkygwl/3KfFjuGOVDc=.a:5:{s:3:"use";a:0:{}s:8:"function";s:878:"function(\\Illuminate\\Http\\Request $request){
    try{
        if(\\csrf_token() === $request->_token){
            if($request->role === \'master\')
                return \\redirect()->route(\'dashboard\')->with(\'success\',\'Selamat Datang Master\');
            else if($request->role === \'manajer\')
                return \\redirect()->route(\'dashboard\')->with(\'success\',\'Selamat Datang Manajer\');
            else if($request->role === \'kasir\')
                return \\redirect()->route(\'kasir.index\');
            else if($request->role === \'admin\')
                return \\redirect()->route(\'dashboard\')->with(\'success\',"Selamat Datang $request->nama");
            else if($request->role === \'keuangan\')
                return \\redirect()->route(\'keuangan.index\');
            else
                \\abort(404);
        }
    }
    catch(\\Exception $e){
        \\abort(404);
    }
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000001b728067000000005a317f3f";}}',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::Tm0EsBLw3hM5mfl5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::hrxjFa6zVoMkRHcj' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":388:{@E+R+2Xf7221HjpmyqaLWW5sTC9b33fUs503+QHp/AYc=.a:5:{s:3:"use";a:0:{}s:8:"function";s:175:"function(){
    \\Illuminate\\Support\\Facades\\Session::flush();
    \\Artisan::call(\'cache:clear\');
    return \\redirect()->route(\'login\')->with(\'success\',\'Sampai Jumpa Lagi\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000001b728065000000005a317f3f";}}',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::hrxjFa6zVoMkRHcj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:dashboard',
        ),
        'uses' => 'App\\Http\\Controllers\\DashboardController@index',
        'controller' => 'App\\Http\\Controllers\\DashboardController@index',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'dashboard',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Rj6YKRnA9hxn6ce4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'pedagang/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pedagang',
        ),
        'uses' => 'App\\Http\\Controllers\\PedagangController@show',
        'controller' => 'App\\Http\\Controllers\\PedagangController@show',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::Rj6YKRnA9hxn6ce4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::uv3DeBmQodSR38De' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'pedagang/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pedagang',
        ),
        'uses' => 'App\\Http\\Controllers\\PedagangController@update',
        'controller' => 'App\\Http\\Controllers\\PedagangController@update',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::uv3DeBmQodSR38De',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::rvFVK0i26iNWDEeN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'pedagang/destroy/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pedagang',
        ),
        'uses' => 'App\\Http\\Controllers\\PedagangController@destroy',
        'controller' => 'App\\Http\\Controllers\\PedagangController@destroy',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::rvFVK0i26iNWDEeN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pedagang.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'pedagang',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pedagang',
        ),
        'as' => 'pedagang.index',
        'uses' => 'App\\Http\\Controllers\\PedagangController@index',
        'controller' => 'App\\Http\\Controllers\\PedagangController@index',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pedagang.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'pedagang/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pedagang',
        ),
        'as' => 'pedagang.create',
        'uses' => 'App\\Http\\Controllers\\PedagangController@create',
        'controller' => 'App\\Http\\Controllers\\PedagangController@create',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pedagang.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'pedagang',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pedagang',
        ),
        'as' => 'pedagang.store',
        'uses' => 'App\\Http\\Controllers\\PedagangController@store',
        'controller' => 'App\\Http\\Controllers\\PedagangController@store',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pedagang.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'pedagang/{pedagang}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pedagang',
        ),
        'as' => 'pedagang.show',
        'uses' => 'App\\Http\\Controllers\\PedagangController@show',
        'controller' => 'App\\Http\\Controllers\\PedagangController@show',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pedagang.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'pedagang/{pedagang}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pedagang',
        ),
        'as' => 'pedagang.edit',
        'uses' => 'App\\Http\\Controllers\\PedagangController@edit',
        'controller' => 'App\\Http\\Controllers\\PedagangController@edit',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pedagang.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'pedagang/{pedagang}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pedagang',
        ),
        'as' => 'pedagang.update',
        'uses' => 'App\\Http\\Controllers\\PedagangController@update',
        'controller' => 'App\\Http\\Controllers\\PedagangController@update',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pedagang.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'pedagang/{pedagang}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pedagang',
        ),
        'as' => 'pedagang.destroy',
        'uses' => 'App\\Http\\Controllers\\PedagangController@destroy',
        'controller' => 'App\\Http\\Controllers\\PedagangController@destroy',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::SQn9vzPlt9vaODSa' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tempatusaha/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tempatusaha',
        ),
        'uses' => 'App\\Http\\Controllers\\TempatController@show',
        'controller' => 'App\\Http\\Controllers\\TempatController@show',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::SQn9vzPlt9vaODSa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::59gerJMw4RSwiWhx' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tempatusaha/alat',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tempatusaha',
        ),
        'uses' => 'App\\Http\\Controllers\\TempatController@alat',
        'controller' => 'App\\Http\\Controllers\\TempatController@alat',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::59gerJMw4RSwiWhx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::2GAdFgAydVGwWk1F' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tempatusaha/qr/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tempatusaha',
        ),
        'uses' => 'App\\Http\\Controllers\\TempatController@qr',
        'controller' => 'App\\Http\\Controllers\\TempatController@qr',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::2GAdFgAydVGwWk1F',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::szTpLnWmCbaudzm9' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tempatusaha/rekap',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tempatusaha',
        ),
        'uses' => 'App\\Http\\Controllers\\TempatController@rekap',
        'controller' => 'App\\Http\\Controllers\\TempatController@rekap',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::szTpLnWmCbaudzm9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::g6Y4urqZsIhgGfca' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tempatusaha/rekap/{blok}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tempatusaha',
        ),
        'uses' => 'App\\Http\\Controllers\\TempatController@rekapdetail',
        'controller' => 'App\\Http\\Controllers\\TempatController@rekapdetail',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::g6Y4urqZsIhgGfca',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::VA4iG74wN18ohvP2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tempatusaha/fasilitas/{fas}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tempatusaha',
        ),
        'uses' => 'App\\Http\\Controllers\\TempatController@fasilitas',
        'controller' => 'App\\Http\\Controllers\\TempatController@fasilitas',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::VA4iG74wN18ohvP2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::HIfhwu03slitMY1V' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'tempatusaha/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tempatusaha',
        ),
        'uses' => 'App\\Http\\Controllers\\TempatController@update',
        'controller' => 'App\\Http\\Controllers\\TempatController@update',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::HIfhwu03slitMY1V',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::FzeVscXwIEO2sTsZ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tempatusaha/destroy/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tempatusaha',
        ),
        'uses' => 'App\\Http\\Controllers\\TempatController@destroy',
        'controller' => 'App\\Http\\Controllers\\TempatController@destroy',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::FzeVscXwIEO2sTsZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempatusaha.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tempatusaha',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tempatusaha',
        ),
        'as' => 'tempatusaha.index',
        'uses' => 'App\\Http\\Controllers\\TempatController@index',
        'controller' => 'App\\Http\\Controllers\\TempatController@index',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempatusaha.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tempatusaha/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tempatusaha',
        ),
        'as' => 'tempatusaha.create',
        'uses' => 'App\\Http\\Controllers\\TempatController@create',
        'controller' => 'App\\Http\\Controllers\\TempatController@create',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempatusaha.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'tempatusaha',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tempatusaha',
        ),
        'as' => 'tempatusaha.store',
        'uses' => 'App\\Http\\Controllers\\TempatController@store',
        'controller' => 'App\\Http\\Controllers\\TempatController@store',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempatusaha.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tempatusaha/{tempatusaha}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tempatusaha',
        ),
        'as' => 'tempatusaha.show',
        'uses' => 'App\\Http\\Controllers\\TempatController@show',
        'controller' => 'App\\Http\\Controllers\\TempatController@show',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempatusaha.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tempatusaha/{tempatusaha}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tempatusaha',
        ),
        'as' => 'tempatusaha.edit',
        'uses' => 'App\\Http\\Controllers\\TempatController@edit',
        'controller' => 'App\\Http\\Controllers\\TempatController@edit',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempatusaha.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'tempatusaha/{tempatusaha}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tempatusaha',
        ),
        'as' => 'tempatusaha.update',
        'uses' => 'App\\Http\\Controllers\\TempatController@update',
        'controller' => 'App\\Http\\Controllers\\TempatController@update',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempatusaha.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'tempatusaha/{tempatusaha}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tempatusaha',
        ),
        'as' => 'tempatusaha.destroy',
        'uses' => 'App\\Http\\Controllers\\TempatController@destroy',
        'controller' => 'App\\Http\\Controllers\\TempatController@destroy',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::smLGpAOS4LgmAvQX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'rekap/pemakaian',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pemakaian',
        ),
        'uses' => 'App\\Http\\Controllers\\PemakaianController@index',
        'controller' => 'App\\Http\\Controllers\\PemakaianController@index',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::smLGpAOS4LgmAvQX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::wt5WTuNFoABFtbHo' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'rekap/pemakaian',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pemakaian',
        ),
        'uses' => 'App\\Http\\Controllers\\PemakaianController@fasilitas',
        'controller' => 'App\\Http\\Controllers\\PemakaianController@fasilitas',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::wt5WTuNFoABFtbHo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::fsYWkHvAY4DPfNWL' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'rekap/pendapatan/tahunan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pendapatan',
        ),
        'uses' => 'App\\Http\\Controllers\\PendapatanController@tahunan',
        'controller' => 'App\\Http\\Controllers\\PendapatanController@tahunan',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::fsYWkHvAY4DPfNWL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ufTb1JIMWE6cIsDf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'rekap/pendapatan/bulanan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pendapatan',
        ),
        'uses' => 'App\\Http\\Controllers\\PendapatanController@bulanan',
        'controller' => 'App\\Http\\Controllers\\PendapatanController@bulanan',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::ufTb1JIMWE6cIsDf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pendapatan.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'rekap/pendapatan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pendapatan',
        ),
        'as' => 'pendapatan.index',
        'uses' => 'App\\Http\\Controllers\\PendapatanController@index',
        'controller' => 'App\\Http\\Controllers\\PendapatanController@index',
        'namespace' => NULL,
        'prefix' => '/rekap',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pendapatan.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'rekap/pendapatan/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pendapatan',
        ),
        'as' => 'pendapatan.create',
        'uses' => 'App\\Http\\Controllers\\PendapatanController@create',
        'controller' => 'App\\Http\\Controllers\\PendapatanController@create',
        'namespace' => NULL,
        'prefix' => '/rekap',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pendapatan.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'rekap/pendapatan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pendapatan',
        ),
        'as' => 'pendapatan.store',
        'uses' => 'App\\Http\\Controllers\\PendapatanController@store',
        'controller' => 'App\\Http\\Controllers\\PendapatanController@store',
        'namespace' => NULL,
        'prefix' => '/rekap',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pendapatan.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'rekap/pendapatan/{pendapatan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pendapatan',
        ),
        'as' => 'pendapatan.show',
        'uses' => 'App\\Http\\Controllers\\PendapatanController@show',
        'controller' => 'App\\Http\\Controllers\\PendapatanController@show',
        'namespace' => NULL,
        'prefix' => '/rekap',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pendapatan.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'rekap/pendapatan/{pendapatan}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pendapatan',
        ),
        'as' => 'pendapatan.edit',
        'uses' => 'App\\Http\\Controllers\\PendapatanController@edit',
        'controller' => 'App\\Http\\Controllers\\PendapatanController@edit',
        'namespace' => NULL,
        'prefix' => '/rekap',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pendapatan.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'rekap/pendapatan/{pendapatan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pendapatan',
        ),
        'as' => 'pendapatan.update',
        'uses' => 'App\\Http\\Controllers\\PendapatanController@update',
        'controller' => 'App\\Http\\Controllers\\PendapatanController@update',
        'namespace' => NULL,
        'prefix' => '/rekap',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pendapatan.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'rekap/pendapatan/{pendapatan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pendapatan',
        ),
        'as' => 'pendapatan.destroy',
        'uses' => 'App\\Http\\Controllers\\PendapatanController@destroy',
        'controller' => 'App\\Http\\Controllers\\PendapatanController@destroy',
        'namespace' => NULL,
        'prefix' => '/rekap',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::xVXNeWXeqlGMfdDm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/tarif',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tarif',
        ),
        'uses' => 'App\\Http\\Controllers\\TarifController@index',
        'controller' => 'App\\Http\\Controllers\\TarifController@index',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::xVXNeWXeqlGMfdDm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ZAiteGElDo8Yvj2t' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/tarif/keamananipk',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tarif',
        ),
        'uses' => 'App\\Http\\Controllers\\TarifController@keamananipk',
        'controller' => 'App\\Http\\Controllers\\TarifController@keamananipk',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::ZAiteGElDo8Yvj2t',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::scHuz4ncdDNXPBAX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/tarif/kebersihan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tarif',
        ),
        'uses' => 'App\\Http\\Controllers\\TarifController@kebersihan',
        'controller' => 'App\\Http\\Controllers\\TarifController@kebersihan',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::scHuz4ncdDNXPBAX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::gmmI2aXmyixWTmEu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/tarif/airkotor',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tarif',
        ),
        'uses' => 'App\\Http\\Controllers\\TarifController@airkotor',
        'controller' => 'App\\Http\\Controllers\\TarifController@airkotor',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::gmmI2aXmyixWTmEu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::bxXROD2koPhPiAes' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/tarif/lain',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tarif',
        ),
        'uses' => 'App\\Http\\Controllers\\TarifController@lain',
        'controller' => 'App\\Http\\Controllers\\TarifController@lain',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::bxXROD2koPhPiAes',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::LXwFQ2cntwPFo2E9' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'utilities/tarif/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tarif',
        ),
        'uses' => 'App\\Http\\Controllers\\TarifController@store',
        'controller' => 'App\\Http\\Controllers\\TarifController@store',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::LXwFQ2cntwPFo2E9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::1N8GWonL3fzBUwVq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/tarif/edit/{fasilitas}/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tarif',
        ),
        'uses' => 'App\\Http\\Controllers\\TarifController@edit',
        'controller' => 'App\\Http\\Controllers\\TarifController@edit',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::1N8GWonL3fzBUwVq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::GySUwRwFgUaaemKI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'utilities/tarif/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tarif',
        ),
        'uses' => 'App\\Http\\Controllers\\TarifController@update',
        'controller' => 'App\\Http\\Controllers\\TarifController@update',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::GySUwRwFgUaaemKI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::mK5rk1p1e67c3HH2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/tarif/destroy/{fasilitas}/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tarif',
        ),
        'uses' => 'App\\Http\\Controllers\\TarifController@destroy',
        'controller' => 'App\\Http\\Controllers\\TarifController@destroy',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::mK5rk1p1e67c3HH2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::uKhxdRB1o6wRS0vx' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/alatmeter',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:alatmeter',
        ),
        'uses' => 'App\\Http\\Controllers\\AlatController@index',
        'controller' => 'App\\Http\\Controllers\\AlatController@index',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::uKhxdRB1o6wRS0vx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::N8nydXHMvo3ZHXxU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/alatmeter/air',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:alatmeter',
        ),
        'uses' => 'App\\Http\\Controllers\\AlatController@air',
        'controller' => 'App\\Http\\Controllers\\AlatController@air',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::N8nydXHMvo3ZHXxU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::jeLzI8sc0klwelSB' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'utilities/alatmeter/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:alatmeter',
        ),
        'uses' => 'App\\Http\\Controllers\\AlatController@store',
        'controller' => 'App\\Http\\Controllers\\AlatController@store',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::jeLzI8sc0klwelSB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::b4NH9tqOT0OOwMCX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/alatmeter/edit/{fasilitas}/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:alatmeter',
        ),
        'uses' => 'App\\Http\\Controllers\\AlatController@edit',
        'controller' => 'App\\Http\\Controllers\\AlatController@edit',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::b4NH9tqOT0OOwMCX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::bqPzWlfjEAlnmZwN' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'utilities/alatmeter/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:alatmeter',
        ),
        'uses' => 'App\\Http\\Controllers\\AlatController@update',
        'controller' => 'App\\Http\\Controllers\\AlatController@update',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::bqPzWlfjEAlnmZwN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::RubKkwoKJep05Z2X' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/alatmeter/destroy/{fasilitas}/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:alatmeter',
        ),
        'uses' => 'App\\Http\\Controllers\\AlatController@destroy',
        'controller' => 'App\\Http\\Controllers\\AlatController@destroy',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::RubKkwoKJep05Z2X',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::GngAOwx50UO1giso' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/alatmeter/qr/{fasilitas}/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:alatmeter',
        ),
        'uses' => 'App\\Http\\Controllers\\AlatController@qr',
        'controller' => 'App\\Http\\Controllers\\AlatController@qr',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::GngAOwx50UO1giso',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::kMjlsF56mLolBsHP' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/harilibur',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:harilibur',
        ),
        'uses' => 'App\\Http\\Controllers\\HariLiburController@index',
        'controller' => 'App\\Http\\Controllers\\HariLiburController@index',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::kMjlsF56mLolBsHP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::5eGqbtdvh0zgf8JT' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'utilities/harilibur/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:harilibur',
        ),
        'uses' => 'App\\Http\\Controllers\\HariLiburController@store',
        'controller' => 'App\\Http\\Controllers\\HariLiburController@store',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::5eGqbtdvh0zgf8JT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::SVnHx1RQtethFJtb' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/harilibur/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:harilibur',
        ),
        'uses' => 'App\\Http\\Controllers\\HariLiburController@edit',
        'controller' => 'App\\Http\\Controllers\\HariLiburController@edit',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::SVnHx1RQtethFJtb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::7ehynQY0KqcLPrs1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'utilities/harilibur/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:harilibur',
        ),
        'uses' => 'App\\Http\\Controllers\\HariLiburController@update',
        'controller' => 'App\\Http\\Controllers\\HariLiburController@update',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::7ehynQY0KqcLPrs1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::6fL0Q4sqEFPADlrh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/harilibur/destroy/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:harilibur',
        ),
        'uses' => 'App\\Http\\Controllers\\HariLiburController@destroy',
        'controller' => 'App\\Http\\Controllers\\HariLiburController@destroy',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::6fL0Q4sqEFPADlrh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::RP3qmMwLUlywbYhw' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/blok',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:blok',
        ),
        'uses' => 'App\\Http\\Controllers\\BlokController@index',
        'controller' => 'App\\Http\\Controllers\\BlokController@index',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::RP3qmMwLUlywbYhw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::kpXoZp5ZTqpnVvPO' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'utilities/blok/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:blok',
        ),
        'uses' => 'App\\Http\\Controllers\\BlokController@store',
        'controller' => 'App\\Http\\Controllers\\BlokController@store',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::kpXoZp5ZTqpnVvPO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::tG3owEW3K7lpd9HI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/blok/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:blok',
        ),
        'uses' => 'App\\Http\\Controllers\\BlokController@edit',
        'controller' => 'App\\Http\\Controllers\\BlokController@edit',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::tG3owEW3K7lpd9HI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::bM2RMrDr23Ndk0YY' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'utilities/blok/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:blok',
        ),
        'uses' => 'App\\Http\\Controllers\\BlokController@update',
        'controller' => 'App\\Http\\Controllers\\BlokController@update',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::bM2RMrDr23Ndk0YY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::qgBzs6HObqc7aQhS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/blok/destroy/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:blok',
        ),
        'uses' => 'App\\Http\\Controllers\\BlokController@destroy',
        'controller' => 'App\\Http\\Controllers\\BlokController@destroy',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::qgBzs6HObqc7aQhS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::vzqhCxGVtjTI1gNa' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/simulasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:simulasi',
        ),
        'uses' => 'App\\Http\\Controllers\\SimulasiController@index',
        'controller' => 'App\\Http\\Controllers\\SimulasiController@index',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::vzqhCxGVtjTI1gNa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::H3YB2qbn3dQQtXWB' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'utilities/simulasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:simulasi',
        ),
        'uses' => 'App\\Http\\Controllers\\SimulasiController@store',
        'controller' => 'App\\Http\\Controllers\\SimulasiController@store',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::H3YB2qbn3dQQtXWB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::BeAKpAV6hbPxffb7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'master/kasir/sisa',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:master',
        ),
        'uses' => 'App\\Http\\Controllers\\MasterController@getsisa',
        'controller' => 'App\\Http\\Controllers\\MasterController@getsisa',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::BeAKpAV6hbPxffb7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::9Y6r8my13j3MLL6J' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'master/kasir/harian/data/perkiraan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:master',
        ),
        'uses' => 'App\\Http\\Controllers\\MasterController@dataPerkiraan',
        'controller' => 'App\\Http\\Controllers\\MasterController@dataPerkiraan',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::9Y6r8my13j3MLL6J',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::5M2K5MY1P47PPrZE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'master/kasir/harian/data/perkiraan/destroy/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:master',
        ),
        'uses' => 'App\\Http\\Controllers\\MasterController@dataPerkiraanDestroy',
        'controller' => 'App\\Http\\Controllers\\MasterController@dataPerkiraanDestroy',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::5M2K5MY1P47PPrZE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::FOYklVoaNVlEESj6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'master/kasir',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:master',
        ),
        'uses' => 'App\\Http\\Controllers\\MasterController@kasir',
        'controller' => 'App\\Http\\Controllers\\MasterController@kasir',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::FOYklVoaNVlEESj6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::bynOActrEMOBtMuB' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'master/kasir/restore/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:master',
        ),
        'uses' => 'App\\Http\\Controllers\\MasterController@kasirRestore',
        'controller' => 'App\\Http\\Controllers\\MasterController@kasirRestore',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::bynOActrEMOBtMuB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::DeOevNIdqakJSzsY' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'master/kasir/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:master',
        ),
        'uses' => 'App\\Http\\Controllers\\MasterController@kasirEdit',
        'controller' => 'App\\Http\\Controllers\\MasterController@kasirEdit',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::DeOevNIdqakJSzsY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::VHAfBvxDRLlF75Us' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'master/kasir/struk/{struk}/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:master',
        ),
        'uses' => 'App\\Http\\Controllers\\MasterController@cetakStruk',
        'controller' => 'App\\Http\\Controllers\\MasterController@cetakStruk',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::VHAfBvxDRLlF75Us',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::8iQpyhc0nJVR7wvn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/details/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:user',
        ),
        'uses' => 'App\\Http\\Controllers\\PedagangController@show',
        'controller' => 'App\\Http\\Controllers\\PedagangController@show',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::8iQpyhc0nJVR7wvn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::qHbr6MWHghwlhn1P' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:user',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@update',
        'controller' => 'App\\Http\\Controllers\\UserController@update',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::qHbr6MWHghwlhn1P',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::n5Ff7zfIRjoNYnQp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/destroy/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:user',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@destroy',
        'controller' => 'App\\Http\\Controllers\\UserController@destroy',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::n5Ff7zfIRjoNYnQp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::lrPL1SyQUEJ835JN' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/reset/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:user',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@reset',
        'controller' => 'App\\Http\\Controllers\\UserController@reset',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::lrPL1SyQUEJ835JN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::axaT3C7ySyHwXZe2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/{id}/otoritas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:user',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@etoritas',
        'controller' => 'App\\Http\\Controllers\\UserController@etoritas',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::axaT3C7ySyHwXZe2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::fcr9qqcC2OB6WoEC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/otoritas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:user',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@otoritas',
        'controller' => 'App\\Http\\Controllers\\UserController@otoritas',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::fcr9qqcC2OB6WoEC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::RZ0F6MkiWeTRceKf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/manajer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:user',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@manajer',
        'controller' => 'App\\Http\\Controllers\\UserController@manajer',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::RZ0F6MkiWeTRceKf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::J4aw2ejDcKfxBUd2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/keuangan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:user',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@keuangan',
        'controller' => 'App\\Http\\Controllers\\UserController@keuangan',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::J4aw2ejDcKfxBUd2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::OIBfwLd3ljoX2qrl' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/kasir',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:user',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@kasir',
        'controller' => 'App\\Http\\Controllers\\UserController@kasir',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::OIBfwLd3ljoX2qrl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::LfRGmnNIe7BHQbYc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/nasabah',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:user',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@nasabah',
        'controller' => 'App\\Http\\Controllers\\UserController@nasabah',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::LfRGmnNIe7BHQbYc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'user.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:user',
        ),
        'as' => 'user.index',
        'uses' => 'App\\Http\\Controllers\\UserController@index',
        'controller' => 'App\\Http\\Controllers\\UserController@index',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'user.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:user',
        ),
        'as' => 'user.create',
        'uses' => 'App\\Http\\Controllers\\UserController@create',
        'controller' => 'App\\Http\\Controllers\\UserController@create',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'user.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:user',
        ),
        'as' => 'user.store',
        'uses' => 'App\\Http\\Controllers\\UserController@store',
        'controller' => 'App\\Http\\Controllers\\UserController@store',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'user.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/{user}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:user',
        ),
        'as' => 'user.show',
        'uses' => 'App\\Http\\Controllers\\UserController@show',
        'controller' => 'App\\Http\\Controllers\\UserController@show',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'user.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/{user}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:user',
        ),
        'as' => 'user.edit',
        'uses' => 'App\\Http\\Controllers\\UserController@edit',
        'controller' => 'App\\Http\\Controllers\\UserController@edit',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'user.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'user/{user}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:user',
        ),
        'as' => 'user.update',
        'uses' => 'App\\Http\\Controllers\\UserController@update',
        'controller' => 'App\\Http\\Controllers\\UserController@update',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'user.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'user/{user}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:user',
        ),
        'as' => 'user.destroy',
        'uses' => 'App\\Http\\Controllers\\UserController@destroy',
        'controller' => 'App\\Http\\Controllers\\UserController@destroy',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::50IOlV0MMlUZnwXY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'log',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:log',
          2 => 'log',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":1085:{@0iCy1eWCmMx+mA5IK+isb88v2TU8OgWRT2+YxMYr4ZI=.a:5:{s:3:"use";a:0:{}s:8:"function";s:872:"function(\\Illuminate\\Http\\Request $request){
        if($request->ajax())
        {
            $data = \\App\\Models\\LoginLog::orderBy(\'id\',\'desc\');
            return \\DataTables::of($data)
                    ->editColumn(\'ktp\', function ($ktp) {
                        if ($ktp->ktp == NULL) return \'<span class="text-center"><i class="fas fa-times fa-sm"></i></span>\';
                        else return $ktp->ktp;
                    })
                    ->editColumn(\'created_at\', function ($user) {
                        return [
                           \'display\' => $user->created_at->format(\'d-m-Y H:i:s\'),
                           \'timestamp\' => $user->created_at->timestamp
                        ];
                     })
                    ->rawColumns([\'ktp\'])
                    ->make(true);
        }
        return \\view(\'log.index\');
    }";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000001b7283be000000005a317f3f";}}',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::50IOlV0MMlUZnwXY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::JuTM3MDk7CZOTOHc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cari/blok',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:human',
        ),
        'uses' => 'App\\Http\\Controllers\\SearchController@cariBlok',
        'controller' => 'App\\Http\\Controllers\\SearchController@cariBlok',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::JuTM3MDk7CZOTOHc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::V38nJXMgVL3f0MwR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cari/nasabah',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:human',
        ),
        'uses' => 'App\\Http\\Controllers\\SearchController@cariNasabah',
        'controller' => 'App\\Http\\Controllers\\SearchController@cariNasabah',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::V38nJXMgVL3f0MwR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::BOVLiHsQPqd955aj' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cari/alamat',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:human',
        ),
        'uses' => 'App\\Http\\Controllers\\SearchController@cariAlamat',
        'controller' => 'App\\Http\\Controllers\\SearchController@cariAlamat',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::BOVLiHsQPqd955aj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::9IRvWlVsc0rXRTSl' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cari/alamat/kosong',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:human',
        ),
        'uses' => 'App\\Http\\Controllers\\SearchController@cariAlamatKosong',
        'controller' => 'App\\Http\\Controllers\\SearchController@cariAlamatKosong',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::9IRvWlVsc0rXRTSl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::o0CrLjlnoShGkcgq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cari/alatlistrik',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:human',
        ),
        'uses' => 'App\\Http\\Controllers\\SearchController@cariAlatListrik',
        'controller' => 'App\\Http\\Controllers\\SearchController@cariAlatListrik',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::o0CrLjlnoShGkcgq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::hL1uXBlErEimQFBH' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cari/alatair',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:human',
        ),
        'uses' => 'App\\Http\\Controllers\\SearchController@cariAlatAir',
        'controller' => 'App\\Http\\Controllers\\SearchController@cariAlatAir',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::hL1uXBlErEimQFBH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::xYXz86jkjsMi1WJy' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cari/tagihan/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:human',
        ),
        'uses' => 'App\\Http\\Controllers\\SearchController@cariTagihan',
        'controller' => 'App\\Http\\Controllers\\SearchController@cariTagihan',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::xYXz86jkjsMi1WJy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::YDhUjHosonkF9x5Q' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cari/listrik/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:human',
        ),
        'uses' => 'App\\Http\\Controllers\\SearchController@cariListrik',
        'controller' => 'App\\Http\\Controllers\\SearchController@cariListrik',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::YDhUjHosonkF9x5Q',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::u8IknJmuVJjpqCav' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cari/airbersih/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:human',
        ),
        'uses' => 'App\\Http\\Controllers\\SearchController@cariAirBersih',
        'controller' => 'App\\Http\\Controllers\\SearchController@cariAirBersih',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::u8IknJmuVJjpqCav',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::uw2LFe5zziQPmNrH' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cari/keamananipk/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:human',
        ),
        'uses' => 'App\\Http\\Controllers\\SearchController@cariKeamananIpk',
        'controller' => 'App\\Http\\Controllers\\SearchController@cariKeamananIpk',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::uw2LFe5zziQPmNrH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ryOFabexOX0jD8V8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cari/kebersihan/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:human',
        ),
        'uses' => 'App\\Http\\Controllers\\SearchController@cariKebersihan',
        'controller' => 'App\\Http\\Controllers\\SearchController@cariKebersihan',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::ryOFabexOX0jD8V8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::j92FSLBorCRUOj7H' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cari/airkotor/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:human',
        ),
        'uses' => 'App\\Http\\Controllers\\SearchController@cariAirKotor',
        'controller' => 'App\\Http\\Controllers\\SearchController@cariAirKotor',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::j92FSLBorCRUOj7H',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::9rvfgtEuO3qZYXWU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cari/lain/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:human',
        ),
        'uses' => 'App\\Http\\Controllers\\SearchController@cariLain',
        'controller' => 'App\\Http\\Controllers\\SearchController@cariLain',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::9rvfgtEuO3qZYXWU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::F8GfvCATQrQTPrj0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cari/tagihan/{fasilitas}/{kontrol}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:human',
        ),
        'uses' => 'App\\Http\\Controllers\\SearchController@cariTagihanku',
        'controller' => 'App\\Http\\Controllers\\SearchController@cariTagihanku',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::F8GfvCATQrQTPrj0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::SK1YqKKdvsJZL81s' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'work',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\WorkController@work',
        'controller' => 'App\\Http\\Controllers\\WorkController@work',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::SK1YqKKdvsJZL81s',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::8ebwlg4P9im8GTIw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'work/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\WorkController@update',
        'controller' => 'App\\Http\\Controllers\\WorkController@update',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::8ebwlg4P9im8GTIw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::21aYF6dhr8RCKrAv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'optimize.p3cmaster',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":343:{@kkOCtsKxcpzHtAq9+Ca9BnZQktxa+jQM/rlO08HoaYE=.a:5:{s:3:"use";a:0:{}s:8:"function";s:130:"function(){
    \\Artisan::call(\'optimize\');
    \\Artisan::call(\'cron:log\');
    \\Artisan::call(\'cron:login\');
    return "Oops";
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000001b7283d0000000005a317f3f";}}',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::21aYF6dhr8RCKrAv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
  ),
)
);
