<div class="table-responsive py-4">
    <table class="table table-flush table-hover table-striped" width="100%" id="tabelKasir">
        <thead class="thead-light">
            <tr>
                <th class="text-center" style="max-width:20%">Kontrol</th>
                <th class="text-center" style="max-width:20%">Tagihan</th>
                <th class="text-center" style="min-width:100px;max-width:25%">Nama</th>
                <th class="text-center" style="min-width:80px;max-width:20%">Ket</th>
                <th class="text-center" style="max-width:15%">Action</th>
            </tr>
        </thead>
    </table>
</div>