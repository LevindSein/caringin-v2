<div class="table-responsive py-4">
    <table class="table table-flush" width="100%" id="tabelAlatListrik">
        <thead class="thead-light">
            <tr>
                <th class="text-center" style="max-width:15%">Kode</th>
                <th class="text-center" style="min-width:80px;max-width:20%">Nomor</th>
                <th class="text-center" style="max-width:20%">Stand</th>
                <th class="text-center" style="max-width:15%">Daya</th>
                <th class="text-center" style="max-width:15%">Status</th>
                <th class="text-center" style="max-width:15%">Action</th>
            </tr>
        </thead>
    </table>
</div>