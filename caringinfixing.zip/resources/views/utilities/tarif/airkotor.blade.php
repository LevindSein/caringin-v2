<div class="table-responsive py-4">
    <table class="table table-flush table-hover table-striped" width="100%" id="tabelAirKotor">
        <thead class="thead-light">
            <tr>
                <th class="text-center" style="max-width:20%">Kategori</th>
                <th class="text-center" style="max-width:65%">Tarif</th>
                <th class="text-center" style="max-width:15%">Action</th>
            </tr>
        </thead>
    </table>
</div>