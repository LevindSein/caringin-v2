<div class="table-responsive py-4">
    <table class="table table-flush" width="100%" id="tabelTunggakan">
        <thead class="thead-light">
            <tr>
                <th class="text-center" style="max-width:25%;">Periode</th>
                <th class="text-center" style="max-width:60%">Selisih</th>
                <th class="text-center" style="max-width:15%">Details</th>
            </tr>
        </thead>
    </table>
</div>