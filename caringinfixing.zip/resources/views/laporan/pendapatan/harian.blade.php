<div class="table-responsive py-4">
    <table class="table table-flush table-hover table-striped" width="100%" id="harian">
        <thead class="thead-light">
            <tr>
                <th class="text-center" style="max-width:10%">Tgl.Bayar</th>
                <th class="text-center" style="max-width:15%">Kontrol</th>
                <th class="text-center" style="min-width:90px;max-width:20%">Pengguna</th>
                <th class="text-center" style="max-width:15%">Tagihan</th>
                <th class="text-center" style="max-width:15%">Realisasi</th>
                <th class="text-center" style="max-width:15%">Selisih</th>
                <th class="text-center" style="max-width:10%">Details</th>
            </tr>
        </thead>
    </table>
</div>