<div class="table-responsive py-4">
    <table class="table table-flush" width="100%" id="tahunan">
        <thead class="thead-light">
            <tr>
                <th class="text-center" style="max-width:30%">Thn.Bayar</th>
                <th class="text-center" style="max-width:50%">Realisasi</th>
                <th class="text-center" style="max-width:20%">Details</th>
            </tr>
        </thead>
    </table>
</div>