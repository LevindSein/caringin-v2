<!DOCTYPE HTML>
<html>
	<head>
		<title>503 Maintenance | BP3C</title>
		<link href="{{asset('css/maintenance/style.css')}}" rel="stylesheet" type="text/css" media="all" />
		<link href='http://fonts.googleapis.com/css?family=Alegreya+Sans:300,400' rel='stylesheet' type='text/css'>
		<link href='http://fonts.googleapis.com/css?family=Titillium+Web:400,300' rel='stylesheet' type='text/css'>
	</head>
	<body>
		<div class="content">
			<div class="wrap">
				<div class="grid">
					<h3>503 | MAINTENANCE MODE</h3>
					<h3>We'll be back soon.</h3>
				</div>
			</div>
			<div class="footer">
				<p>&copy;2020 PT Pengelola Pusat Perdagangan Caringin</p>
			</div>
		</div>
	</body>
</html>