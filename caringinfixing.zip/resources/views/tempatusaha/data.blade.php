@extends('tempatusaha.index')

@section('titles')
<title>Data Tempat Usaha | BP3C</title>
@endsection

@section('juduls')
<h6 class="h2 text-white d-inline-block mb-0">Data Tempat Usaha</h6>
@endsection

@section('contents')
@if(Session::get('role') == 'master' || Session::get('role') == 'admin')
<div class="table-responsive py-4">
    <table class="table table-flush" width="100%" id="tabelTempat">
        <thead class="thead-light">
            <tr>
                <th class="text-center" style="max-width:15%">Kontrol</th>
                <th class="text-center" style="max-width:20%">Pengguna</th>
                <th class="text-center" style="max-width:20%">Lokasi</th>
                <th class="text-center" style="max-width:5%">Jml.Los</th>
                <th class="text-center" style="max-width:20%">Usaha</th>
                <th class="text-center" style="max-width:10%">Action</th>
                <th class="text-center" style="max-width:10%">Details</th>
            </tr>
        </thead>
    </table>
</div>
@else
<div class="table-responsive py-4">
    <table class="table table-flush" width="100%" id="tabelTempat1">
        <thead class="thead-light">
            <tr>
                <th class="text-center" style="max-width:20%">Kontrol</th>
                <th class="text-center" style="max-width:20%">Pengguna</th>
                <th class="text-center" style="max-width:20%">Lokasi</th>
                <th class="text-center" style="max-width:10%">Jml.Los</th>
                <th class="text-center" style="max-width:20%">Usaha</th>
                <th class="text-center" style="max-width:10%">Details</th>
            </tr>
        </thead>
    </table>
</div>
@endif
@endsection

@section('modals')
@endsection

@section('jss')
@endsection